﻿// -----------------------------------------------------------------------
// <copyright file="Wrapper2.cs" company="Microsoft">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace Weavers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class Wrapper2<T> where T : class
    {
        public T Wrapped;
    }
}
