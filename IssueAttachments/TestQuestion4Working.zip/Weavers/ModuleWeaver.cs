﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weavers
{
    using AspectData;

    using Mono.Cecil;
    using Mono.Cecil.Rocks;

    public class ModuleWeaver
    {
        public ModuleDefinition ModuleDefinition { get; set; }

        public IAssemblyResolver AssemblyResolver { get; set; }

        public Action<string> LogInfo { get; set; }

        public Action<string> LogWarning { get; set; }

        public Action<string> LogError { get; set; }

        public void Execute()
        {
            foreach (var typeDefinition in ModuleDefinition.Types)
            {
                foreach (var fieldDefinition in typeDefinition.Fields)
                {
                    MutatePersistentFields(fieldDefinition);
                }
            }
        }

        private void MutatePersistentFields(FieldDefinition fieldDefinition)
        {
            CustomAttribute attribute;
            if (fieldDefinition.TryGetAttribute("ModFlag", out attribute))
            {
                var createdGenericType = this.MakeGenericWrapper(fieldDefinition.FieldType);
                fieldDefinition.FieldType = createdGenericType;
            }
        }

        private TypeReference MakeGenericWrapper(TypeReference type)
        {
            var typeRef = this.GetWrapperType();

            var refGenericType = typeRef.MakeGenericInstanceType(type);
            return refGenericType;
        }

        private TypeReference GetWrapperType()
        {
            var assemblyDef = AssemblyResolver.Resolve("AspectData");
            var typeRef = assemblyDef.MainModule.Types.FirstOrDefault(t => t.Name == "Wrapper`1");
            var typeDef = ModuleDefinition.Import(typeRef);
            return typeDef;
        }
    }

    public static class DefinitionHelper
    {
        public static bool ContainsAttribute(this ICustomAttributeProvider definition, string attributeName)
        {
            return definition.CustomAttributes.Any(x => x.Constructor.DeclaringType.Name == attributeName);
        }

        public static bool TryGetAttribute(
            this ICustomAttributeProvider definition, string attributeName, out CustomAttribute attrubute)
        {
            attrubute =
                definition.CustomAttributes.FirstOrDefault(x => x.Constructor.DeclaringType.Name == attributeName);
            return attrubute != null;
        }
    }
}
