﻿namespace AspectData
{
    using System;

    /// <summary>
    /// ...
    /// </summary>
    [AttributeUsage(AttributeTargets.Field)]
    public class ModFlag : Attribute
    {
    }
}
