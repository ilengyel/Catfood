﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weavers
{
    using AspectData;

    using Mono.Cecil;
    using Mono.Cecil.Rocks;

    public class ModuleWeaver
    {
        public ModuleDefinition ModuleDefinition { get; set; }

        public IAssemblyResolver AssemblyResolver { get; set; }

        public Action<string> LogInfo { get; set; }

        public Action<string> LogWarning { get; set; }

        public Action<string> LogError { get; set; }

        public void Execute()
        {
            foreach (var typeDefinition in ModuleDefinition.Types)
            {
                foreach (var fieldDefinition in typeDefinition.Fields)
                {
                    MutatePersistentFields(fieldDefinition);
                }
            }
        }

        private void MutatePersistentFields(FieldDefinition fieldDefinition)
        {
            CustomAttribute attribute;
            if (fieldDefinition.TryGetAttribute("ModFlag", out attribute))
            {
                var createdGenericType = this.MakeGenericWrapper(fieldDefinition.FieldType);
                fieldDefinition.FieldType = createdGenericType;
            }
        }

        private TypeReference MakeGenericWrapper(TypeReference type)
        {
            //var typeRef = ModuleDefinition.Import(typeof(Wrapper<>));   // throws: Could not load file or assembly 'AspectData, Version=...
            //var typeRef = this.GetWrapperType();                        // throws: Member 'AspectData.Wrapper`1' is declared in another module and needs to be imported
            // I also tried suffixing .Resolve() to the previous two lines


            var typeRef = ModuleDefinition.Import(typeof(Wrapper2<>));    // works when type is in the weaver project

            var refGenericType = typeRef.MakeGenericInstanceType(type);
            return refGenericType;
        }

        private TypeReference GetWrapperType()
        {
            var assemblyRef = ModuleDefinition.AssemblyReferences.First(ass => ass.Name == "AspectData");
            var assemblyDef = AssemblyResolver.Resolve(assemblyRef.FullName);
            var typeRef =
                assemblyDef.Modules.Select(mod => mod.Types.FirstOrDefault(t => t.Name == "Wrapper`1")).First(
                    type => type != null);
            return typeRef;
        }
    }

    public static class DefinitionHelper
    {
        public static bool ContainsAttribute(this ICustomAttributeProvider definition, string attributeName)
        {
            return definition.CustomAttributes.Any(x => x.Constructor.DeclaringType.Name == attributeName);
        }

        public static bool TryGetAttribute(
            this ICustomAttributeProvider definition, string attributeName, out CustomAttribute attrubute)
        {
            attrubute =
                definition.CustomAttributes.FirstOrDefault(x => x.Constructor.DeclaringType.Name == attributeName);
            return attrubute != null;
        }
    }
}
